/**
 * Examples
 */
package gettingstarted;